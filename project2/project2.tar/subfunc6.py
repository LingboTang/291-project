from validity import *
import os

def subfunc6():
    os.system('cls' if os.name == 'nt' else 'clear')
    return 