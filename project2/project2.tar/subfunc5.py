from validity import *
import os
import time

def subfunc5():
    #select = 'y'
    #while select == 'y':
    os.system('cls' if os.name == 'nt' else 'clear')
    print('Destroy the database')
    #code
    print('Database destroyed')
    print("The program runs %.6f seconds"%time.clock())
    #select = validity("Do you want to register another vehicle? y/n: ", "Please enter a valid option: ", 1, str, ['y', 'n'], 'lower')
    #os.system('cls' if os.name == 'nt' else 'clear')
    #print()