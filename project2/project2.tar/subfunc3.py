from validity import *
import os
import time

def subfunc3():
    select = 'y'
    while select == 'y':
        os.system('cls' if os.name == 'nt' else 'clear')
        print('Retrieve records with a given data')
        #code
        print('Key: \n'+'Value: \n')
        print("The program runs %.6f seconds"%time.clock())
        select = validity("Do you want to find another value? y/n: ", "Please enter a valid option: ", 1, str, ['y', 'n'], 'lower')
        os.system('cls' if os.name == 'nt' else 'clear')
        #print()