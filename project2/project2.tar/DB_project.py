import sys
import cx_Oracle
import getpass
import random
import string 
import datetime
import time
from func1 import func1
from func2 import func2
from func3 import func3
from func4 import func4
from func5 import func5
from subfunc1 import subfunc1
from subfunc11 import subfunc11
from subfunc111 import subfunc111
from subfunc2 import subfunc2
from subfunc3 import subfunc3
from subfunc4 import subfunc4
from subfunc5 import subfunc5
from subfunc6 import subfunc6
from validity import *
import os
#from ctype import cdll

# Berkeley DB Example

#__author__ = "Bing Xu"
#__email__ = "bx3@ualberta.ca"

#import bsddb3 as bsddb
#import random
# Make sure you run "mkdir /tmp/my_db" first!
#DA_FILE = "/tmp/my_db/sample_db"
#DB_SIZE = 1000
#SEED = 10000000

#def get_random():
#	return random.randint(0,63)
#def get_random_char():
	#return chr(97 + random.randint(0,25))


def main():
	#first = True
	#check = True
	try:
		options = {1: func1, 2: func2, 3: func3}
		while True:
			
			os.system('cls' if os.name == 'nt' else 'clear')
			print('MAIN MENU')
			print()
			print(' 1 - Operations for B-tree structure\n 2 - Operations for Hash Tree structure\n 3 - Operations for Index File\n 4 - Exit')
			choice = validity("Please select a number option from the options above: ", "Please select a valid option: ", 1, int, ['1','2','3','4'])		
			try:
				options[choice]()
			except:
				break
			
			choice = validity("1 - Main Menu \n2 - Exit \nSelection: ", "Please input a valid option: ", 1, str, ['1', '2'])
			
			if choice == '2':
				break
			else:
				print()		
				
		os.system('cls' if os.name == 'nt' else 'clear')	
	except:
		print('wrong')
		
if __name__ == "__main__":
	main()#call main function