from validity import *
import os

def func4():
    os.system('cls' if os.name == 'nt' else 'clear')
    return 