from validity import *
import os
import time

def subfunc4():
    select = 'y'
    while select == 'y':
        os.system('cls' if os.name == 'nt' else 'clear')
        print('Retrieve records with a given range of key values')
        #code
        print('Key: \n'+'Value: \n')
        print("The program runs %.6f seconds"%time.clock())
        select = validity("Do you want to search another range? y/n: ", "Please enter a valid option: ", 1, str, ['y', 'n'], 'lower')
        os.system('cls' if os.name == 'nt' else 'clear')
        #print()